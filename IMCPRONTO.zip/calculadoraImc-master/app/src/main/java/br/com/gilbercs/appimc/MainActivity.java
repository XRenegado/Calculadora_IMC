package br.com.gilbercs.appimc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText edtCampoPeso, edtCampoAltura;
    private Button btnCalcular, btnLimpar;
    private TextView txtSeuImc, txtInterpretacaoImc, txtInformacao;

    public void inicializarComponentes() {
        edtCampoPeso = (EditText) findViewById(R.id.idCampoPeso);
        edtCampoAltura = (EditText) findViewById(R.id.idCampoAltura);
        btnCalcular = (Button) findViewById(R.id.idBtnCalcular);
        btnLimpar = (Button) findViewById(R.id.idBtnLimpar);
        txtSeuImc = (TextView) findViewById(R.id.idTxtSeuImc);
        txtInformacao = (TextView) findViewById(R.id.idTxtInformacao);
        txtInterpretacaoImc = (TextView) findViewById(R.id.idTxtInterpretacaoImc);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializarComponentes();
        txtSeuImc.setVisibility(View.GONE);
        txtInformacao.setVisibility(View.GONE);
        txtInterpretacaoImc.setVisibility(View.GONE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.idDev:
                startActivity(new Intent(MainActivity.this, SobreActivity.class));
                break;
            case R.id.idSair:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void calcularImc(View view) {
        String strCampoPeso, strCampoAltura;
        strCampoPeso = edtCampoPeso.getText().toString();
        strCampoAltura = edtCampoAltura.getText().toString();




            if (!strCampoPeso.isEmpty()) {
                if (!strCampoAltura.isEmpty()) {
                    Double nome, peso, altura, calculo;
                    peso = Double.parseDouble(strCampoPeso);
                    altura = Double.parseDouble(strCampoAltura);
                    altura = altura * altura;
                    calculo = peso / altura;
                    if (calculo > 0) {
                        txtSeuImc.setVisibility(View.VISIBLE);
                        txtSeuImc.setText("o seu imc é: " + Math.round(calculo));
                        txtInformacao.setVisibility(View.VISIBLE);
                        txtInterpretacaoImc.setVisibility(View.VISIBLE);
                        interpretacaoImc(calculo);
                    }
                } else {

                    Toast.makeText(MainActivity.this,
                            "bota a altura bunda mole",
                            Toast.LENGTH_LONG).show();
                    edtCampoAltura.requestFocus();
                }
            } else {

                Toast.makeText(MainActivity.this,
                        "bota o peso seu bundao",
                        Toast.LENGTH_LONG).show();
                edtCampoPeso.requestFocus();
            }
        }

        public void limparCampos (View view){
            txtSeuImc.setVisibility(View.GONE);
            txtInformacao.setVisibility(View.GONE);
            txtInterpretacaoImc.setVisibility(View.GONE);
            edtCampoPeso.setText("");
            edtCampoAltura.setText("");
            txtSeuImc.setText("");
            edtCampoPeso.requestFocus();
        }

        public void interpretacaoImc (Double imc){
            if (imc < 18.5) {
                txtInterpretacaoImc.setText("menor do que 18,5 = abaixo do peso ideal");
            } else {
                if (imc >= 18.5 && imc < 24.9) {
                    txtInterpretacaoImc.setText("entre 18,5 e 24,9 = Peso ideal");
                } else {
                    if (imc == 25) {
                        txtInterpretacaoImc.setText(" 25 = Possibilidade de sobrepeso");
                    } else {
                        if (imc > 25 & imc <= 29.9) {
                            txtInterpretacaoImc.setText("entre 25,0 e 29,9 = pré obesidade");
                        } else {
                            if (imc >= 30 && imc <= 34.9) {
                                txtInterpretacaoImc.setText("entre 30,0 e 34,9 = obesidade de primeiro grau");
                            } else {
                                if (imc >= 35 && imc <= 39.9) {
                                    txtInterpretacaoImc.setText("entre 35,0 e 39,9 = obesidade de segundo grau");
                                } else {
                                    if (imc > 40) {
                                        txtInterpretacaoImc.setText("maior ou igual a 40 = obesidade de terceiro grau");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

